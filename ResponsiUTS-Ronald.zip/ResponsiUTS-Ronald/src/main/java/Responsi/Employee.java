/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Responsi;

/**
 *
 * @author ASUS
 */
public class Employee {
    private String namaPegawai;
    private double gaji;

    // Constructor
    public Employee(String namaPegawai, double gaji) {
        this.namaPegawai = namaPegawai;
        this.gaji = gaji;
    }

    // Getter dan Setter [cite: 14]
    public String getNamaPegawai() {
        return namaPegawai;
    }

    public void setNamaPegawai(String namaPegawai) {
        this.namaPegawai = namaPegawai;
    }

    public double getGaji() {
        return gaji;
    }

    public void setGaji(double gaji) {
        this.gaji = gaji;
    }

    // Metode untuk menampilkan info
    public void tampilkanInfo() {
        System.out.println("Nama Pegawai: " + getNamaPegawai());
        System.out.println("Gaji: " + (int)getGaji());
    }
}
