/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Responsi;

/**
 *
 * @author ASUS
 */
public class Main {
    public static void main(String[] args) {
        // 1. Output Produk [cite: 25]
        System.out.println("1. Output Produk");
        Product produk1 = new Electronics("Laptop", 15000000, 2);
        produk1.tampilkanInfo();
        System.out.println();

        // 2. Output Pegawai [cite: 28]
        System.out.println("2. Output Pegawai");
        Permanent pegawai1 = new Permanent("Budi", 5000000, 1000000); // Sesuaikan nama "Budi" [cite: 29]
        pegawai1.tampilkanInfo();
        System.out.println();

        // 3. Output Polimorfisme [cite: 21, 31]
        System.out.println("3. Output Polimorfisme");

        // Membuat objek dari kelas turunan dan menyimpannya dalam referensi kelas induk [cite: 22]
        Product produkPolimorfis = new Food("Snack", 15000, "2023-12-30");
        produkPolimorfis.tampilkanInfo();
        System.out.println();

        Employee pegawaiPolimorfis = new Contract("Andi", 3000000, 12);
        pegawaiPolimorfis.tampilkanInfo();
    }
}
